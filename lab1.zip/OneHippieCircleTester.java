import java.util.Scanner;

public class OneHippieCircleTester {

	public static void main(String[] args) {

		//Create hippie circle full of 13 pillows
		OneHippieCircle hc = new OneHippieCircle(13, 2, "Amelia");



		//Print out hippie's name and position, mover her forward, and print again		
		System.out.println(hc.getHippie() + " is sitting at position " + hc.getPos());

		//Resize circle and print to see how hippie got affected
        hc.resizeCircle(5);
        hc.moveClockwiseOne();
                hc.moveClockwiseOne();

        hc.moveClockwiseOne();

        hc.moveClockwiseOne();

		System.out.println(hc.getHippie() + " is now sitting at position " + hc.getPos());


		//Replace hippie in circle
        hc.replaceHippie("Layla");
		System.out.println(hc.getHippie() + " is sitting at position " + hc.getPos());

		//Create new circle!

		// //Print out hippie's name and position, mover her forward, and print again
		// System.out.println(cepsr750.getHippie() + " is in chair " + cepsr750.getPos());
		// cepsr750.moveForward();
		// System.out.println(cepsr750.getHippie() + " is in chair " + cepsr750.getPos());
		
		// //How many times should the hippie move places?
		// Scanner s = new Scanner(System.in);
		// System.out.println("How many times do you want the hippie to move forward?");
		// int x = s.nextInt();

		
		// //Resize circle and print to see how hippie got affected
		// cepsr750.resizeCircle(5); //Note that there's nothing here to catch!
		// System.out.println(hippie + " is in chair " + cepsr750.getPos());

		// //Replace hippie in circle
		// cepsr750.replaceHippie("Rodin");
		// Systemout.println("How many times should new hippie move backwards?");
		// x = s.nextInt();
		// for(;x > 0; x--) 
		// 	cepsr750.moveBackward();
		// //How should we print out the name of this new hippie?
		// System.out.println(cepsr750.getHippie() + " is in chair " + cepsr750.getPos()); 

		// //Let's create a new hippie circle
		// OneHippieCircle csb451 = new OneHippieCircle();
		// hippie = "Joi";
		// csb451.replaceHippie(hippie); //REM: new HippieCircles are constructed with "Niki" as default hippie

		// //How many times should the hippie move places in new circle?
		// System.out.println("How many times should new hippie move forward?");
		// x = s.nextInt();
		// for(;x--;)
		// 	csb451.moveForward();
		// System.out.println("\n\n" + hippie + " is in chair " + csb451.getPos());		

	}

}