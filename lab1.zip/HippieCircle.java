import java.util.Scanner;

public class HippieCircle {

  public static void main(String[] args) {

    //Declare variable(s) that will represent the circle AND its size
    int circle;

    //Create a Scanner object to take input from keyboard at runtime
    Scanner s = new Scanner(System.in);

    //Use Scanner to ask user for size of circle
    System.out.println("How large do you want the circle?");
    circle = s.nextInt();
    
    /*
     * Invite hippie to circle
     *     1. Use Scanner to ask them for their name
     *     2. User Scanner again to ask for where they would like to sit
     */
    System.out.println("Hey what's your name?");
    //Note below declaration and initialization happening concurrently!
    String name = s.next();
    System.out.println("Hey " + name + "! There are " + circle + " seats available. Where do you wanna sit?");

    //Add hippie to circle
    int position = s.nextInt();

    //Now the hippie wants to move one position CLOCKWISE
    position = (position + 1) % circle;
    System.out.println(name + " moves one position clockwise and is now on pillow " + position);
    
    //Now the hippie wants to move six positions CLOCKWISE
    position = (position + 6) % circle;
    System.out.println(name + " moves 6 positions clockwise and is now on pillow " + position);

    //Now the hippie wants to move 3 positions COUNTER CLOCKWISE
    position = (position + (circle-3)) % circle;
    System.out.println(name + " moves 3 positions counter clockwise and is now on pillow " + position);

    //The sun went down and the hippie has left
    circle = -1;

    //No more hippies will come to circle today
    s.close();

  }
  
}