public class OneHippieCircle {

	/* 1) Declare my INSTANCE VARIABLES */
	private int circle;
	private String hippie;
	private int position;	

	/* 2) Create my CONSTRUCTOR (i.e. INITIALIZE my INSTANCE VARIABLES) */
	public OneHippieCircle(int size, int pos, String name) {

		this.circle = size;
		this.hippie = name;
		position = pos;	

	}

	/* 3) DEFINE my METHODS */

	//MUTATOR: replace hippie to hippie circle
	public void replaceHippie(String name) {

		hippie = name;

	}


	//ACCESSOR: gets hippie name
	public String getHippie() { return hippie; }
	

	//ACCESSOR: returns position of person in hippie circle
	public int getPos() { return position; }
	


	//MUTATOR: move hippie clockwise in hippie circle
	public void moveClockwiseOne() {

		position = (position + 1) % circle;

	}



	//MUTATOR: move hippie backward in hippie circle
	public void moveCounterClockwiseOne() {

		position = (position + (circle-1)) % circle;

	}


	//MUTATOR: resize the circle
	public void resizeCircle(int newSize) {

		circle = newSize;
		//moveClockwiseOne(); //ensures hippie is within new circle bounds!

	}

	
}